
# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# MEMBER LOGIN DETAILS

$m1_mid = "10597530"
$m1_email = "test_aut123qa@hjsk.com"
$m1_passwd = "test_aut123qa@hjsk.com"
$m1_site = "Surveyhead"

$m2_mid = "10597537"
$m2_email = "test_aut125qa@hjsk.com"
$m2_passwd = "test_aut125qa@hjsk.com"
$m2_site = "Surveyhead"

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'