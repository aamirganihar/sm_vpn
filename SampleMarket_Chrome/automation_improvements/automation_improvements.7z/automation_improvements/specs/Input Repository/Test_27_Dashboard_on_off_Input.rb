# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# MEMBER LOGIN DETAILS

$m1_mid = "10598078"
$m1_email = "dash_on_off@mailinator.com"
$m1_passwd = "dash_on_off@mailinator.com"
#$m1_site = "Surveyhead"