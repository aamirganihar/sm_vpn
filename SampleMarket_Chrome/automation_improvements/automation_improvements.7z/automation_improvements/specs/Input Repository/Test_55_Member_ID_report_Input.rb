# MEMBER ID REPORT INPUT

# USAMP NETWORK PUBLISHER LOGIN CREDENTIALS

$unet_email = 'auto_test_pub1@mailinator.com'
$unet_pass = 'test'
$type = 'Publisher'

$mid = 'TEST_MID_RH'
#$s = 'TEST_S_RH'
#$sp = 'TEST_SP_RH'