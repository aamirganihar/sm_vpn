# MEMBER ACCOUNT CLOSE INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# FOCUSLINE MEMER DETAILS

$FCLN_email = 'rahul1486@testmail.comxyz'
$FCLN_passwd = 'test'
$mid = '1442206'
