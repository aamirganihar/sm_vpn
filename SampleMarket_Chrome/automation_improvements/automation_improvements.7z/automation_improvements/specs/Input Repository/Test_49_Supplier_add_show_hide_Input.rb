# SUPPLIER ADDITION & SHOW/HIDE SUPPLIER INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

#NETWORK SITE CLIENT LOGIN DETAILS#

$email = "rahul_halankar@persistent.co.in"
$passwd = "1234"
$type = "Client"

$cp_sheild_id = '3139'