# BROADCAST / EMAIL INVITE INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$member_id_1 = '10606227'
$mem_email = 'usamp_bcast1@rediffmail.com'

$redf_uname = 'usamp_bcast1'
$redf_pass = 'test!@#'

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'

$member_id_2 = '10606281'
$mem_email_2 = 'usamp_bcast2@rediffmail.com'