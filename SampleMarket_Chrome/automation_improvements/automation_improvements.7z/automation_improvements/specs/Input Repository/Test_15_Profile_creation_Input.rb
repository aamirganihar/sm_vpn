# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


#PROFILE CREATION DETAILS#
$prof_name = "Test Profile"
$prf_cat = "Automation Profile"
$prf_rew = "2"
$qn_per_page = "2"
#PROFILEICON	:: C:\Winter.jpg
$prof_exp = "0"
$age_min = "10"
$age_max = "99"

#ADDING INDUSTRY DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$ind_opt1 = "Aerospace & Defense"
#INDUSTRYOPTIONS	:: Agribusiness
#INDUSTRYOPTIONS	:: Computers: Software / Services

#ADDING ETHNICITY DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #

$ethnic = "African American"
#ETHNICITY 	:: Asian (non Pacific Islander)
#ETHNICITY 	:: Caucasian

#ADDING ROLE/DEPARTMENT DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$role = "Administration / Management"
#ROLE		:: Construction / Maintenance / Real Estate
#ROLE		:: Executives

#ADDING EDUCATION DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #

$edu ="High school graduate"
#EDUCATION	:: Some college or university
#EDUCATION	:: College graduate with a 4 year degree

#ADDING EMPLOYMENT DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$employment = "Full-Time Employee"
#EMPLOYMENT	:: Homemaker
#EMPLOYMENT	:: Part-Time Employee

#ADDING MARITIAL STATUS#
#USER CAN SELECT MULTIPLE OPTIONS #

$marital = "Never married"
#MARITIAL	:: Married
#MARITIAL	:: Living with Partner


# ADDING QUESTIONS #
$qn1 = "Which car do you own?"

# ANSWERS #

$ans_1_1 = "BMW"
$ans_1_2 = "AUDI"	 
$ans_1_3 ="MERC"
$ans_1_4 = "FERRARI"

$qn2 = "What is your Date of birth?"

$qn3 = "What is your nationality?"

$ans_3_1 = "AMERICAN"
$ans_3_2 = "FRENCH"
$ans_3_3 =	"INDIAN"
$ans_3_4 =	"CHINESE"

$qn4 = "How is your new car?"

$ans_4_1 = "Excellent"
$ans_4_2 =	"Good"
$ans_4_3 = "Average"

$qn5 = "Do you wish to buy a car?"
$qn6 = "How do you travel?"
$qn7 = "Do you wish to buy another car?"

$ans_7_1 = "YES"
$ans_7_2 = "NO"
#44#
$qn8 = "Select the water power for your state ?"
$ans_8 = "%%STATE_WATRPWR%%"
$qn9 = "Select the hospital in your area ?"
$ans_9 = "%%STATE_HOSPITAL%%"
$qn10 = "Select the gas provider for your state ?"
$ans_10 = "%%STATE_GAS%%"
$qn_11 = "Select the utility provider for your state ?"
$ans_11 = "%%STATE_UTILITY%%"
#52#
$qn_12 = "Do you have more than 1 car?"
$qn_13 = "Do you wish to buy one more car?"

$qn_14 = "Which all cars do you have ?"
$qn_15 = "Which car do you wish to buy?"

