# QG NOTIFICATIONS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$pub_name = "Test PUB (30 Sept)"
$no_of_clicks = '2'
$employee = 'AUTO EMPLOYEE Do Not Change!!'