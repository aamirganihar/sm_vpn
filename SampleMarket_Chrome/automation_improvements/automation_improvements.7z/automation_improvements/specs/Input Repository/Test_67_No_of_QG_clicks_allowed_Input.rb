# NO. OF QG CLICKS ALLOWED PER MEMBER FROM DASHBOARD INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$member_id_1 = '10626291'
$mem_email = 'dbclick1@testmail.com'
$mem_passwd = 'dbclick1@testmail.com'

$no_of_dashboard_clicks_allowed = '2'
$no_of_dashboard_clicks_allowed_2 = '4'

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'