# PUBLISHER CLIENT ASSOCIATION INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$pub_id = 'PU346'

$client_id = '60'
$client_name = 'TEST CLIENT COMPANY (RRH)'