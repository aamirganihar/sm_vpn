# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$inv_token = '2d8194b087c6df677a9f442ca1cad1d8'