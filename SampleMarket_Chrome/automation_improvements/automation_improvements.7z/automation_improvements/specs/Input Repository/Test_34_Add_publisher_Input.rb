# ADD NEW PUBLISHER INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


#UNITED SAMPLE PROJECT CREATION DETAILS #
$fname = 'Test Auto First Name'
$lname = 'Test Auto Last Name'
#$email = 'Test_Auto'
$country = 'India'
$passwd = 'test'

#Costs#
$panel_signup = '1'
$fixed_signup = '1'
