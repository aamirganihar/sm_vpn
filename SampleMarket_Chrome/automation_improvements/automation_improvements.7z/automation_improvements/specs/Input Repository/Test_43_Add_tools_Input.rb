# ADDITIONAL TOOLS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# ADDITIONAL TOOLS DETAILS

$zip = '90001'

$token = '03051118a00903a6809efe2b3fc2ba49'