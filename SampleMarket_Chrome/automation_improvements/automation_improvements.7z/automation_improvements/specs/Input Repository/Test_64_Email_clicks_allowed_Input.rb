# NO. OF EMAIL CLICKS ALLOWED INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$member_id_1 = '10606227'
$mem_email = 'usamp_bcast1@rediffmail.com'

$no_of_email_clicks_allowed = '2'