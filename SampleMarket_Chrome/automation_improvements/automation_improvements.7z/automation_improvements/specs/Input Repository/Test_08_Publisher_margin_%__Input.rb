# PUBLISHER MARGIN PERCENTAGE INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

#PUBLISHER DETAILS

$pub_id = "PU164"

# MARGIN PERCENTAGE SETTINGS

$fixed_payout = "1"
$margin = "70"
$margin_mismatch = "71"

#FOCUSLINE CREDENTIALS

$m_eml = "test_pub_cat@mail.com"
$m_pswd = "test_pub_cat@mail.com"