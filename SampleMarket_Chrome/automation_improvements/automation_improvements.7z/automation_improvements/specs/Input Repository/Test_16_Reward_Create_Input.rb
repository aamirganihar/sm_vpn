

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# REWARD DETAILS

$Description="
<p> Reward Desciption </p>
<p>  Data
Reward Name : %%rewardname%% 	
First name : %%firstname%% 	
Email : %%email%% 
</p>"

$Catalog="
<p> Reward Desciption </p>
<p>  Data 
Reward Name : %%rewardname%% 	
First name : %%firstname%% 	
Email : %%email%% 
</p>"

$Redemption="
<p> Reward Desciption </p>
<p>  Gift code : %%giftcode%% 	Gift Amount : %%giftamount%% 	Gift Url : %%gifturl%% </p>"

$Email="
<p> Email Contents</p><p>  DataInstructions : %%instructions%% 	Password : %%password%% </p>"

# MEMEBER CREDENTIALS

$mem_em = "auto_rew_mem@mailop.com"
$mem_passwd = "auto_rew_mem@mailop.com" 