# PR INVOICING WORKFLOW INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$member_id_1 = ''
$mem_email = 'test_mem_click@testmail.com'
$mem_passwd = 'test_mem_click@testmail.com'

$billing_code = '01-test code do not assign'
