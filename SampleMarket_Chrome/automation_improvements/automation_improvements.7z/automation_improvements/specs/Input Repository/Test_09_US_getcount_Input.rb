# US GET COUNT INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# QG CRITERIA DETAILS
$wd=Dir.pwd

$ethnicity = "Native American, Eskimo, Aleutian"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"
#$area_code_path = $wd+"/Config Management/US_AREACODE.csv"
$area_code = "213,323,0,310,562,714,626,818,805,661,909,951,619,760,858,949,559,209,831,650,408,415,916,510,707,925,530,808,684,671,969,691,670,692,541,503,253,425,360,206,509,907"
$cbsa = "31100"
$country_fips = "06037"
$dma = "803"
$miles = "5"
$miles_zip = "90002"
$msa_pmsa = "4472"
$state = "California"
$county = "LOS ANGELES"
$city = "LOS ANGELES"
$state_fips = "6"
#$zip_code_path = $wd+"/Config Management/US_ZIP_CODE.csv"
$zip_code = "90001,90002,90003,90004,90005,90006,90007,90008,90009,90010,90011,90012,90013,90014,90015,90016,90017,90018,90019,90020,90021,90022,90023,90024,90025,90026,90027,90028,90029,90030,90031,90032,90033,90034,90035,90036,90037,90038,90039,90040,90041,90042,90043,90044,90045,90046,90047,90048,90049,90050,90051,90052,90053,90054,90055,90056,90057,90058,90059,90060,90061,90062,90063,90064,90065,90066,90067,90068,90069,90070,90071,90072,90073,90074,90075,90076,90077,90078,90079,90080,90081,90082,90083,90084,90086,90087,90088,90089,90090,90091,90093,90094,90095,90096,90099,90101,90103,90189,90201,90202,90209,90210,90211,90212,90213,90220,90221,90222,90223,90224,90230,90231,90232,90233,90239,90240,90241,90242,90245,90247,90248,90249,90250,90251,90254,90255,90260,90261,90262,90263,90264,90265,90266,90267,90270,90272,90274,90275,90277,90278,90280,90290,90291,90292,90293,90294,90295,90296,90301,90302,90303,90304,90305,90306,90307,90308,90309,90310,90311,90312,90401,90402,90403,90404,90405,90406,90407,90408,90409,90410,9041"

# SURVEYHEAD/PL SIGNUP DETAILS

$url = "http://www.sm.p.surveyhead.com"
$country = "United States"
$lang = "English"
$zip_match = "90001"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$state_mismatch = "Georgia"

# PROFILE CRITERIA DETAILS

$prof_nm = "P169:Tier 1 - _uSamp - Casinos & Gambling"
$quest = "Q4099: Thank you for agreeing to participate in our casinos and gambling profile! Based on your responses, we may invite you to participate in future surveys ranging on a wide variety of interesting topics. How many times have you visited Las Vegas within the last 12 months?"
$ans = "None"
$prof_disnm = "Casinos & Gambling - US English (JB & LWB)"


$pub_id = "PU164"