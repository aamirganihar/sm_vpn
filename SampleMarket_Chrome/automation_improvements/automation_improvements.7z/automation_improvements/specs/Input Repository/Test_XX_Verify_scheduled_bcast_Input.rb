# VERIFY SCHEDULED BCAST INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$redf_uname = 'usamp_bcast2'
$redf_pass = 'test!@#'