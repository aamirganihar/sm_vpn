# MEMBER SEARCH EDIT INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# MEMBER DETAILS

$mid = 'M1442322'
$fname = 'test'
$lname = 'member'
$email = 'rahul1486@gmail.comxyz'
$passwd = 'test'
#$pub = ''
$site = 'FocuslineSurveys'