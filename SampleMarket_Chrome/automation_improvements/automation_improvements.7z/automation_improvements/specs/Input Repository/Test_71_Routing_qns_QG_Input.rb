# ROUTING QUESTION CASES 

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$prf = "Tier 1 - _uSamp - Casinos & Gambling"
$ans_id = "59546"

$mem_email = 'rout_qn1@testmail.com'
$mem_passwd = 'rout_qn1@testmail.com'

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'

#MEMBER DETAILS

$country = "United States"
$lang = "English"
$zip_match = "90001"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$state = "California"
$ethnicity = "Native American, Eskimo, Aleutian"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"

$pub_id = 'PU264'
$prof_id = '169'
