#

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'