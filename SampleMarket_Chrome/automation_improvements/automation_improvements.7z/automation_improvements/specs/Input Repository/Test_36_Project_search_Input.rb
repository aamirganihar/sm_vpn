# PROJECT SEARCH INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "vipul_paikane@persistent.co.in"
$admin_passwd = "test"

#PROJECT DETAILS#

$prj_id = 'PR6515'
$prj_name = 'Samsung Cross Media XM (TRACKER) - 05/23'
$status = 'Archived'


#QUOTA GROUP BELONGING TO ABOVE PROJECT#
$qg_id = 'QG25963'
$qg_status = 'Closed'
$qg_cat = 'Consumer'
$sub_cat = '--Select Sub Category--'
$client = 'Dynamic Logic'
$client_pm = 'Jason Deutsch'
$start_dt = '2010-03-01'
$end_dt = '2010-07-01'
