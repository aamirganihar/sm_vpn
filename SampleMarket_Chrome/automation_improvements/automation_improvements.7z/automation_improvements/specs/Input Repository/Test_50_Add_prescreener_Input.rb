# ADD PRESCREENER & PASS/FAIL CASES INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$cat = "Business"
$qn = 'Test Prescreener question..?'
$op1 = '1'
$op2 = '2'

