# CONFIG SETTINGS CASES - REWARDS CASH OUT % & DEFAULT FIRST SURVEY CPI / CAP AMOUNT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$member_id_1 = ''
$mem_email = 'rew_cashout_mem@testmail.com'
$mem_passwd = 'rew_cashout_mem@testmail.com'

$rew_cashout = '24'
$fcpi = '5.00'
$cap_amt = '4.00'
$rew_cost = '0.48' # $rew_cost = $rew_cashout * $qg_reward / 100 ($qg_reward = 1 in this case)

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'

$pub_id = 'PU486'
