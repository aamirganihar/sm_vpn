# SUCCESS/FAIL/OVERQUOTA REWARDS AT SITE LEVEL INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"
$site_id = '0'

#$fail_rew_amt = '2'
#$oq_rew_amt = '3'
#$new_sc_rew = '5'

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'
$fl_red_url = 'http://p.u-samp.com/redirect.php?S=2'
$oq_red_url = 'http://p.u-samp.com/redirect.php?S=3'

# MEMBER CREDENTIALS

$m1_email = 'testplscrew@testmail.com'
$m1_passwd = 'testplscrew@testmail.com'
$m1_mid = '10604367'

$m2_email = 'testplflrew@testmail.com'
$m2_passwd = 'testplflrew@testmail.com'
$m2_mid = '10604368'

$m3_email = 'testploqrew@testmail.com'
$m3_passwd = 'testploqrew@testmail.com'
$m3_mid = '10604369'