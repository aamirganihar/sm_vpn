

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"
$site_id = "2"

#PL SITE LOGIN DETAILS

#$m1_mid = "4584659"
$m1_email = "std_red_mem1@mailop.com"
$m1_passwd = "test"
#$m1_site = "Surveyhead"

#$m2_mid = "4584666"
$m2_email = "iframe_red_mem1@mailop.com"
$m2_passwd = "test"
#$m2_site = "Surveyhead"

# PUBLISHER DETAILS

$pub_id = "PU164"