# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"
$site_id = "2"

$m1_email = "prof_ans_mem1@mailop.com"
$m1_passwd = "prof_ans_mem1@mailop.com"