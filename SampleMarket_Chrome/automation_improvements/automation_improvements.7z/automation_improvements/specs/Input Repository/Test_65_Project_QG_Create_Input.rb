# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

#PROJECT CREATION DETAILS
$proj_status = "Open"
$proj_type = "Survey"
$proj_end_date = "2015-10-20"
$bid_no = "1200123"
$booked_month = "February"
$booked_year = "2011"
$booked_rev = "12000"
$proj_rev = "1200000"
$exp_close_month = "February"
$exp_close_year = "2011"
$client = "TEST CLIENT (RRH)"
$sales_rep = "Rahul Halankar"
$client_pm = "test fname test lname"
$upload_file_loc = "" 

#QUOTA GROUP DETAILS 

$qg_status = "Open"
$qg_close_date = "2015-12-30 "
$n = "100"
$inc = "2"
$inc_range = "General_population"
$qg_cat = "Business"
$length = "2"
$cpi = "10"
$rew_type = "Cash" # (Cash/Sweepstakes)
$rew_amt = "2"
$fail_rew_amt = '1'
$oq_rew_amt = '1'
$survey_url = "http://203.199.26.75/usamp/TEST_SURVEY.php"
$pub_name = "Test PUB (30 Sept)"

#QUOTA GROUP CRITERIA

$ethnicity = "Native American, Eskimo, Aleutian"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"