# PUBLISHER CATEGORY FILTER INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

#PUBLISHER DETAILS

$pub_id = "PU164"

# CATEGORIES

$match_cat = "Business"
$mismatch_cat = "Computers"

#FOCUSLINE CREDENTIALS

$m_eml = "test_pub_cat@mail.com"
$m_pswd = "test_pub_cat@mail.com"