# LISTING PROJECTS ON DASHBOARD INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


$prj_mngr = "akshata shanbhag"
$sales_rep1 = "akshata shanbhag"
$buss_dev = "Rahul Halankar"


