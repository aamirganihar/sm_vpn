# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"
$site_id = "2"

#PROFILE CREATION DETAILS#
$prof_name = "Test Profile"
$prf_cat = "Automation Profile"
$prf_rew = "2"
$qn_per_page = "2"
#PROFILEICON	:: C:\Winter.jpg
$prof_exp = "0"
$age_min = "10"
$age_max = "99"

#ADDING INDUSTRY DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$ind_opt1 = "Aerospace & Defense"
#ADDING ETHNICITY DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$ethnic = "African American"
#ADDING ROLE/DEPARTMENT DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$role = "Administration / Management"
#ADDING EDUCATION DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$edu ="High school graduate"
#ADDING EMPLOYMENT DETAILS#
#USER CAN SELECT MULTIPLE OPTIONS #
$employment = "Full-Time Employee"
#ADDING MARITIAL STATUS#
#USER CAN SELECT MULTIPLE OPTIONS #
$marital = "Never married"


$exs_quest = 'Do you wish to buy a car?'
$crit_quest = 'Which car do you own?'

$m1_email = 'jhcks369@jsgkg.com'
$m1_passwd = 'jhcks369@jsgkg.com'