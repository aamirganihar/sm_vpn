# ENABLE/DISABLE QUEUE2 PAGE INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# PUBLISHER DETAILS

$pub_id = '613'
$country = 'United States'
$zip_code = '50001'
$date = '04'
$month = 'July'
$year = '1985'
$gender = 'Male'
$ethnicity = 'Asian (non Pacific Islander)'
$income = '19,999 or less'
$email_adr = 'test_auto_em@testmail.com'