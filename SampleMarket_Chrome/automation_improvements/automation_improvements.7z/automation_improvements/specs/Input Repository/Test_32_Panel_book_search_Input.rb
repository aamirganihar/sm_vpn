# PANEL BOOK SEARCH INPUT

$search_string = 'Red Bull'