# QG NOTIFICATIONS EMAIL DELIVERY INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$no_of_clicks = '2'

$redf_uname = 'usamp_adm1'
$redf_pass = 'test!@#'