# EMAIL LINK TO PUBLISHER INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# PUBLISHER DETAILS

$pub_email = 'auto_test_pub1@mailinator.com'
$pub_id = '467'