# EX/ST LINKS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$pub_id = '467'
$pub_st = 'http://www.google.com'

$country = "United States"
$lang = "English"
$zip_match = "90001"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$state = "California"
$ethnicity = "Native American, Eskimo, Aleutian"
$ethnicity_mismatch = "Caucasian"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"