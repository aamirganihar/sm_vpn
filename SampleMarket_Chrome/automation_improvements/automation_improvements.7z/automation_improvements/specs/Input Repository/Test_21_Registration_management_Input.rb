
# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# SURVEYHEAD/PL SIGNUP DETAILS

$url = "http://www.sm.p.surveyhead.com"
$country = "Djibouti"
$city = "Dikhil"
$lang = "English"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"
$state = "Dikhil"