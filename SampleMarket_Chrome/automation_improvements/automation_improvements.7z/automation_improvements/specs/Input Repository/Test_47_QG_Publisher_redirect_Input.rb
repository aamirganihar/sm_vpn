# QG PUBLISHER REDIRECT LINKS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# PUBLISHER DETAILS

$pub_id = '265'
$pub_name = 'AUTOMATION PUBLISHER'
$ext_sc = 'http://203.199.26.75/usamp/SC.php?MID=%%MID%%&SP=%%SP%%'
$ext_fl = 'http://203.199.26.75/usamp/FL.php?MID=%%MID%%&SP=%%SP%%'
$ext_oq = 'http://203.199.26.75/usamp/OQ.php?MID=%%MID%%&SP=%%SP%%'
$pub_st = 'http://www.google.com'
$mid1 = 'TEST_QG_MID'
$sp1 = 'TEST_QG_SP'
$mid2 = 'TEST_PUB_MID'
$sp2 = 'TEST_PUB_SP'
