# CONFIRMIT CODE/URL RECONTACT CASES INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$def_srv_url = 'http://203.199.26.75/usamp/TEST_SURVEY.php'
$code_survey_url = 'http://203.199.26.75/usamp/TEST_SURVEY.php?CLIENT_CODE=%%clientcode%%&TOKEN=%%token%%'
$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'

# MEMBER CREDENTIALS

$m1_email = 'test_confm1@testmail.com'
$m1_passwd = 'test_confm1@testmail.com'
$m1_mid = '10601607'

$m2_email = 'test_confm2@testmail.com'
$m2_passwd = 'test_confm2@testmail.com'
$m2_mid = '10601608'

$m3_email = 'test_confm3@testmail.com'
$m3_passwd = 'test_confm3@testmail.com'
$m3_mid = '10601618'

$m4_email = 'test_confm4@testmail.com'
$m4_passwd = 'test_confm4@testmail.com'
$m4_mid = '10601619'

$tok1 = '090eef9ac4a7bbf01956f1a8df047a80'
$tok2 = 'a8326d4289e5216d27c71c6f6c1ed172'

$code1 = 'X422300008'
$url1 = 'http://203.199.26.75/usamp/RECONTACT_CONF_URL.php'
