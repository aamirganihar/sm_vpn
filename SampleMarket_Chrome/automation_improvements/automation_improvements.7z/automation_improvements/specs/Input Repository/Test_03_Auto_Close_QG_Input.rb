# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# AUTO CLOSE OPTIONS

$no_of_clicks = "1"
$no_of_completes = "1"