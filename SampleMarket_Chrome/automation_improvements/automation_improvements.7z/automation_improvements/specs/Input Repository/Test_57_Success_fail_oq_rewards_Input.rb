# SUCCESS/FAIL/OVERQUOTA REWARDS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$fail_rew_amt = '2'
$oq_rew_amt = '3'
$new_sc_rew = '5'

$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'
$fl_red_url = 'http://p.u-samp.com/redirect.php?S=2'
$oq_red_url = 'http://p.u-samp.com/redirect.php?S=3'

# MEMBER CREDENTIALS

$m1_email = 'testscrew@testmail.com'
$m1_passwd = 'testscrew@testmail.com'
$m1_mid = '10601569'

$m2_email = 'testflrew@testmail.com'
$m2_passwd = 'testflrew@testmail.com'
$m2_mid = '10601570'

$m3_email = 'testoqrew@testmail.com'
$m3_passwd = 'testoqrew@testmail.com'
$m3_mid = '10601571'

