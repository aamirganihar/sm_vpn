

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"
$site_id = "2"

#MEMBER LOGIN DETAILS

$m_email = "rahul_halankar@persistent.co.in"
$m_passwd = "test"