# SH EMAIL UPDATE INPUT

$sh_email = 'test_12@psl.com'
$sh_passwd = 'test_12'
$new_email = 'new_dummy_addr@mailinator.com'