# ADD NEW PUBLISHER INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# USAMPADMIN EMPLOYEE DETAILS

$dept = "Business Development Dept"
$fname = "TEST_EMP_FNAME"
$lname = "TEST_EMP_LNAME"
