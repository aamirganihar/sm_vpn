#TRADIONAL PIXEL INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


$pub_id = "467"
#$sc_pix_code = '[CURL]http://203.199.26.75/usamp/Test_auto/pixel_test.php?user1=%%CPI%%&user2=%%CASHREWARD%%&user3=%%QGID%%&user4=%%QGDESCRIPTION%%[CURL]'
#$fl_oq_pix_code = '[CURL]http://203.199.26.75/usamp/Test_auto/pixel_test.php?user1=%%CPI%%&user2=%%MID%%&user3=%%QGID%%&user4=%%QGDESCRIPTION%%[CURL]'
#$reg_pix_code = '[CURL]http://203.199.26.75/usamp/Test_auto/pixel_test.php?user1=%%MID%%&user2=%%S%%&user3=%%SP%%&user4=%%MID%%[CURL]'
#$prof_pix_code = '[CURL]http://203.199.26.75/usamp/Test_auto/pixel_test.php?user1=%%PROFILEREWARDAMOUNT%%&user2=%%PROFILEDESCRIPTION%%&user3=%%MID%%&user4=%%PROFILEID%%[CURL]'

$sc_pix_code = '%%CPI%%%%CASHREWARD%%%%QGID%%%%QGDESCRIPTION%%'
$fl_oq_pix_code = '%%QGID%%%%QGDESCRIPTION%%'
$reg_pix_code= '%%MID%%%%S%%%%SP%%'
$prof_pix_code = '%%PROFILEREWARDAMOUNT%%%%PROFILEDESCRIPTION%%%%PROFILEID%%'
  	

$url = "http://www.sm.p.surveyhead.com"
$country = "United States"
$lang = "English"
$zip_match = "90001"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$state = "California"
$ethnicity = "Native American, Eskimo, Aleutian"
$inc_level = "Prefer not to answer"
$origin = "Mayotte"
$education = "Advanced degree"

#PIXELS

$mid = "TEST_MID_RH"
$s = "TEST_S_RH"
$sp = "TEST_SP_RH"
$prof_id = "300"
$sc_red_url = 'http://p.u-samp.com/redirect.php?S=1'

$pix_cpi = "1.00"
$qg_dsc = "AUTO TEST SURVEY"
$pix_rew = "2.00"
$pix_prof_dsc = "PIXEL TEST"
$pix_prof_rew = "2.00"