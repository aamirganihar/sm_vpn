# CHECK SETTING UP / LIVE / CLOSED QGS INPUT

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

# USAMP NETWORK PUBLISHER LOGIN CREDENTIALS

$unet_email = 'auto_test_pub1@mailinator.com'
$unet_pass = 'test'
$type = 'Publisher'
