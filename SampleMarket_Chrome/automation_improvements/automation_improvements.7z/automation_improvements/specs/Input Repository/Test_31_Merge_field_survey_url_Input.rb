# TRY ANOTHER SURVEY

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

#PL LOGIN

$pl_email = "gsk@hk.com"
$pl_passwd = "gsk@hk.com"