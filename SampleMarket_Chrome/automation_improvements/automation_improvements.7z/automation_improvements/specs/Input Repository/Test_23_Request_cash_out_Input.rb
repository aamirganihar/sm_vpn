

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# MEMBER LOGIN DETAILS

#$m1_mid = "4584659"
$m1_email = "test_aut123qa@hjsk.com"
$m1_passwd = "test_aut123qa@hjsk.com"
#$m1_site = "Surveyhead"

#$m1_email = "Cashout_Mail_Test.des@mailop.com"
#$m1_passwd = "test"

