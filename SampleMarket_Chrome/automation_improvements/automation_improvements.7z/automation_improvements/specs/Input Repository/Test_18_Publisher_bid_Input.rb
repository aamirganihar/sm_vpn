
# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"


# PUB DETAILS

$pubid = "PU1164"
$pubname = "AUTO BIDDING PUB"
$pub_email = "auto_bid@mailop.com"
$pub_pass = "test"
$cpi = "1"
$n = "10"

