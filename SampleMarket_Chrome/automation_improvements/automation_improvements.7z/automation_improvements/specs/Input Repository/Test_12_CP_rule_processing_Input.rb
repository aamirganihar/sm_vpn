# CLIENT PANELSHIELD RULE PROCESSING INPUT

#NETWORK SITE CLIENT LOGIN DETAILS#

$email = "rahul_halankar@persistent.co.in"
$passwd = "1234"
$type = "Client"

#CLIENT PANELSHIELD PROJECT DETAILS#

$country = "UNITED STATES"
$survey_length = "5"

#SUPPLIER ADDITION DETAILS#

$sup_name = "Clear Voice"
$sup_allowed_link= "http://203.199.26.75/usamp/Test_auto/TEST_CP_SURVEY.php"
$sup_reject_link = "http://203.199.26.75/usamp/Test_auto/TEST_CP_REJ.php"
$sup_id = "59"

# USAMPADMIN LOGIN CREDENTIALS

$admin_email = "rahul_halankar@persistent.co.in"
$admin_passwd = "rahul123"

$client = "Test_New_Client (PShield)"
$sup_name_2 = "AIP Corp"
$sup_id2 = "1"
