# FACEBOOK CONNECT INPUT

# USAMPADMIN LOGIN CREDENTIALS

#$admin_email = "rahul_halankar@persistent.co.in"
#$admin_passwd = "rahul123"

# FACEBOOK CREDENTIALS

$FB_email = 'test_surveyhead_facebook@mailop.com'
$FB_pass = 'surveyfb'

$linked_SH_acc = 'test_fb_link@testmail.com'
#ABOVE FB ACCOUNT IS LINKED TO BELOW STAGE SURVEYHEAD ACCOUNT
# email: test_usamp_fb_acc@mailinator.com
# password: test