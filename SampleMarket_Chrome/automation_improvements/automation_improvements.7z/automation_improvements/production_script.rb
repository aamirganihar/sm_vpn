require 'rubygems'
require './automation'
#Load WATIR
require 'optparse'
require 'fileutils'
# Load WIN32OLE library
require 'win32ole'
require 'Win32API'
#Load the win32 library
require 'win32/clipboard'
include Win32
#require 'md5'
require 'base64'
require 'YAML'

#require 'InputRepository/Basic_data'

#include 'Suite'

#PRE REQUISITES :-
#Login Credentials, Project Creation data

describe "Test 00: Production basic tests" do

  before(:all) do
      driver = Selenium::WebDriver.for :firefox, :profile => "Selenium"
      @browser = Watir::Browser.new driver
      @browser.goto('https://network.usamp.com/login.php')
      @browser.radio(:value, "Client").set
      @browser.text_field(:id, "txtEmail").set("sangeeta_pai@persistent.co.in")
      @browser.text_field(:id, "txtPassword").set("spai")
      #Click login button
      @browser.link(:id,"btnLogin").click
	  sleep 3
  end
  

    it "To successfully create a SM project" do
        @browser.goto("https://network.usamp.com/SelfServe/index.php?mode=report/projectslanding")
        @browser.link(:text,"Add a new project").click
        prj_name= Time.now
        prj_name = prj_name.to_s
        prj_name = prj_name.slice(0..18)

        @date=Time.now.strftime("%m/%d/%Y")
        @SECONDS_PER_DAY = 60 * 60 * 24
        @date_added_1=(Time.now + 1*@SECONDS_PER_DAY).localtime.strftime("%m/%d/%Y")
        @date_added_10=(Time.now + 10*@SECONDS_PER_DAY).localtime.strftime("%m/%d/%Y")
      

        prj_name = "Production Automation"+prj_name
        project_name = {}
        project_name['project'] = prj_name
        File.open("InputRepository/projectname.yml","w"){|file| YAML.dump(project_name,file)}
        @browser.text_field(:id, "txtPrjName").set(prj_name)
        @browser.select_list(:id,"optPrjCat").select("Business")
        @browser.select_list(:id,"optPM").select("mayuri rivankar")
        @browser.select_list(:id,"optSalesRep").select("san pai-test1")    
        @date=Time.now.strftime("%m/%d/%Y")
        @SECONDS_PER_DAY = 60 * 60 * 24
        @date_added_1=(Time.now + 1*@SECONDS_PER_DAY).localtime.strftime("%m/%d/%Y")
        @date_added_10=(Time.now + 10*@SECONDS_PER_DAY).localtime.strftime("%m/%d/%Y")
        @browser.text_field(:id, "txtSurveyLength").set("2")
        @browser.text_field(:name ,'txtStartDate').set @date_added_1
        @browser.text_field(:name ,'txtEndDate').set @date_added_10
        @browser.checkbox(:name,"chkRelvantId").set(false)
        @browser.checkbox(:name,"chkRelvantId").set(false)
        @browser.link(:text,'Create Project').click
        sleep 2
        body_text = @browser.text
        body_text.should include("Your project has been created")
    end
    


    it "To successfully set Demographic criteria for a group" do
        @browser.link(:text,/Group Setup/).click
        #@browser.link(:text,/GROUP SETUP/).click
        sleep 2
       
        @browser.checkbox(:id,"PL[0]").set
        @browser.link(:text,/Demographic Targeting/).click
        while @browser.div(:id=>"fancybox-loading").visible? do
            sleep 0.5
            puts "waiting for element"
        end
        @browser.link(:text,/Age /).click
        while @browser.div(:id=>"fancybox-loading").visible? do
            sleep 0.5
            puts "waiting for element"
    end
    sleep 4
        
        @browser.text_field(:id,"txtAgeGenderRangeLower_1").set("90")
        @browser.text_field(:id,"txtAgeGenderRangeUpper_1").set("99")
        sleep 2
        @browser.checkbox(:id,"rdFemaleAgeGender1").set
        #@browser.link(:text,/SAVE and add another category/).click
        @browser.link(:text,/Done/).click
        @browser.link(:text,/90-99/).should exist
    end
    

    it "To successfully set Geographic criteria for a group" do
        @browser.link(:text,/Geographic Targeting/).click
		sleep 0.5
        @browser.link(:text,/Zip Code/).click
        while @browser.div(:id=>"fancybox-loading").visible? do
            sleep 0.5
            puts "waiting for element"
    end
    sleep 4
        @browser.text_field(:id,"txtZipList").set("98765")
        @browser.link(:text,/Done/).click
        @browser.link(:text,/98765/).should exist
    end
    

    it "To check if the get sample counts displays proper count" do
        grp_name= Time.now
        grp_name = grp_name.to_s
        grp_name = grp_name.slice(0..18)
        grp_name = "Production_Automation_Group"+grp_name
        @browser.text_field(:id,"txtGroupName").set(grp_name)
        @browser.text_field(:id,"txtSampleSize").set("15")
        @browser.text_field(:id,"txtIncidenceEst").set("100")
        @browser.checkbox(:id,"PL[0]").set
        @browser.link(:text,"Get Sample Counts").click
        while @browser.div(:id=>"spanDisplayRefrStatsLoadingStatus").visible? do
            sleep 1
    end
    sleep 2
            
        body_text = @browser.html
        html_array = body_text.split(/\n/)
        0.upto(html_array.size - 1) { |index|
        if(html_array[index] =~ />Surveyhead</)
            @code = html_array[index]
            break
            else
                next
            end
            }
            @code1 = @code.slice(467..470)
            @code1 = @code1.gsub(/,/, "")
            @number = @code1.to_i

            @number.should > 5
            @number.should < 35
        end
        
    it "To complete successful creation of group" do
        @browser.link(:id,"next").click
        sleep 1
        @browser.text_field(:index,0).set("5")   
        @browser.text_field(:index,1).set("0.01")   
        @browser.text_field(:index,2).set("5")   
        @browser.link(:id,"addCostsNextButton").click
        @browser.checkbox(:id,"tc").set
        @browser.text_field(:id,"textfield").set("sangeeta pai")
        sleep 3
        @browser.link(:text,"Finish").click
        sleep 6
        body_text = @browser.text
		sleep 3
        body_text.should include("Your groups have been defined")
        @browser.link(:text,"Prepare to go live").click
        sleep 8
        @browser.link(:id,"btnApply").click
        @browser.checkbox(:id,"chkClicksAllowed").set(false)
        @browser.checkbox(:id,"chkGeoIP").set(false)
        @browser.checkbox(:id,"chkRejProxy").set(false)
        @browser.checkbox(:id,"chkRejSpeeder").set(false)
        #@browser.checkbox(:id,"chkRelevantId").set(false)
        @browser.link(:text,"Next").click
        @browser.checkbox(:index,0).set
        
        @grp_name= Time.now
        @grp_name = @grp_name.to_s
        @grp_name = @grp_name.slice(0..18)
        @grp_name = "Production please ignore"+@grp_name
        @browser.text_field(:id,"survey_name").set(@grp_name)
        group_name = {}
        group_name['group'] = @grp_name
        File.open("InputRepository/groupname_Demo.yml","w"){|file| YAML.dump(group_name,file)}
        @browser.link(:id,"btnNext").click
	@browser.checkbox(:id,"multiple_clicks_allowed").set
        @browser.link(:text,"Next").click
        @browser.text_field(:id,"txtSurveyUrl").set("http://www.google.com?id=%%Token%%")
        sleep 2
        @browser.link(:id,"btnSaveURL").click
        sleep 5
        @browser.link(:id,"succes_status").should exist
        @browser.link(:id,"succes_status").click
        @browser.window(:title => /Google/).use do
            @browser.goto("http://sm1mr.com/ssred.php?S=1&ID=")
            sleep 2
            @browser.button(:id,"btnClose").click
        end
        sleep 2
        @browser.link(:id,"fail_status").click
        @browser.window(:title => /Google/).use do
            @browser.goto("http://sm1mr.com/ssred.php?S=2&ID=")
            body_text = @browser.text
            body_text.should include("The fail redirect has passed for this URL!")
            sleep 2
            @browser.button(:id,"btnClose").click
        end
        sleep 2
        @browser.link(:id,"finishBtn").click
        sleep 2
        @browser.link(:text,/Go to Project Page/).click
        sleep 5
        @browser.link(:text,/Go Live/).click
        sleep 2
        body_text = @browser.text
        body_text.should include("You are about to go live with these groups/channels.")
        @browser.link(:text,/golive/).click
        sleep 15
        @browser.link(:text,"Pause").should exist
	sleep 2
        @browser.link(:text,"Close").should exist
    end
    
    it "To Get Project and group details for survey Taking and Get IDs" do
	    sleep 3
        @browser.link(:text,/Production_Automation_Group/).click
	sleep 8
        @group_url=@browser.url
        #puts @group_url
        @enc_group_name=/groupid=(\w+)=/.match(@group_url)
        # @enc_group_name=/groupid=([A-Za-z])+==/
		
		#Begin changes- SangeetaPai- 03 Jan 2012
				
		if @enc_group_name.nil?
			@enc_group_name=/groupid=(\w+)#/.match(@group_url)			
		end
		#end of changes- SangeetaPai
		
		sleep 5
		
		
        @enc_group_name=@enc_group_name.to_s()
        # puts @enc_group_name
        @enc_group_name=@enc_group_name[8..15]
        @dec_group_id=Base64.decode64(@enc_group_name)
        #puts @dec_group_id
        @dec_group_link="link"+@enc_group_name
        #@browser.link(:text,/SampleMarket/).click
        #p "#{@prj_name}"
        p "one:#{@dec_group_link}"
        #body_text = @browser.text
        #body_text.should include("#{@prj_name}")
        group_id = {}
        group_id['group_id'] = @dec_group_id
        group_id['group_link'] = @dec_group_link

        File.open("InputRepository/Group_Ids_Stats_prod.yml","w"){|file| YAML.dump(group_id,file)}
    end
   
    it "To check if a member is able to see the survey, clico on it, complete it and check for the rewards" do
        group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_id =  group_id['group_id']
        #group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_link = group_id['group_link']


        driver = Selenium::WebDriver.for :firefox, :profile => "Selenium"
        @browser1 = Watir::Browser.new driver
        @browser1.goto('http://surveyhead.com')
        @browser1.text_field(:name, "txtEmail").set("sangeeta_pai@mailop.com")
        @browser1.text_field(:name, "txtPassword").set("sangeeta_pai@mailop.com")
        @browser1.button(:value,"login").click
        sleep 3
=begin	
	if(@browser1.link(:id,"sb-nav-close").exists?)
	      @browser1.link(:id,"sb-nav-close").click
      end
=end      
      sleep 5
      
      if(@browser1.div(:id=>"loadingSurveys").exists?)
	      while @browser1.div(:id=>"loadingSurveys").visible? do
		      sleep 0.5
		      puts "waiting for surveys to load"
	      end
      end
      sleep 2
        body_text = @browser1.text
        body_text.should include("#{@dec_group_id}")
            @browser1.link(:id,"#{@dec_group_link}").click
        @browser1.button(:name,'Submit').click
        sleep(2)
        @browser1.window(:title => /Google/).use do
        @browser1.goto("http://sm1mr.com/ssred.php?S=1&ID=")
        body_text = @browser1.text
        body_text.should include("CONGRATULATIONS")
        @browser1.link(:text,"Rewards").click
        @text_contents=@browser1.html
        @text_array =@text_contents.split(/\n/)
        0.upto(@text_array.size - 1) { |index|
        if(@text_array[index] =~ /#{@dec_group_id}/)
            @text_array[index+5].should include("1.00")
            next
            else
            end
            }
        end
        @browser1.link(:text,"Logout").click
        system("cookies.bat")
        @browser1.close
        sleep 2
    end
    
        
        
    


    it "To check if a member is able to fail the survey" do
        group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_id =  group_id['group_id']
        group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_link = group_id['group_link']
        driver = Selenium::WebDriver.for :firefox, :profile => "Selenium"
        @browser1 = Watir::Browser.new driver
        @browser1.goto('http://surveyhead.com')
        @browser1.text_field(:name, "txtEmail").set("sangeeta@mailop.com")
        @browser1.text_field(:name, "txtPassword").set("sangeeta@mailop.com")
        @browser1.button(:value,"login").click
        #sleep 3
	sleep 3
=begin	
	if(@browser1.link(:id,"sb-nav-close").exists?)
	      @browser1.link(:id,"sb-nav-close").click
      end
=end      
      sleep 5
      
      if(@browser1.div(:id=>"loadingSurveys").exists?)
	      while @browser1.div(:id=>"loadingSurveys").visible? do
		      sleep 0.5
		      puts "waiting for surveys to load"
	      end
      end
      sleep 2
        body_text = @browser1.text
        body_text.should include("#{@dec_group_id}")
        @browser1.link(:id,"#{@dec_group_link}").click
        @browser1.button(:name,'Submit').click
        sleep(2)
        @browser1.window(:title => /Google/).use do
            @browser1.goto("http://sm1mr.com/ssred.php?S=2&ID=")
            body_text = @browser1.text
            body_text.should include("SORRY")
        end
        @browser1.link(:text,"Logout").click
        system("cookies.bat")
        @browser1.close
    end
    
  
    it "To check if a member is able to generate over quota for a survey" do
        group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_id =  group_id['group_id']
        group_id = File.open("InputRepository/Group_Ids_Stats_prod.yml"){|file| YAML::load(file)}
        @dec_group_link = group_id['group_link']
        driver = Selenium::WebDriver.for :firefox, :profile => "Selenium"
        @browser1 = Watir::Browser.new driver
        @browser1.goto('http://surveyhead.com')
        @browser1.text_field(:name, "txtEmail").set("sangeeta1@mailinator.com")
        @browser1.text_field(:name, "txtPassword").set("sangeeta1@mailinator.com")
        @browser1.button(:value,"login").click
        sleep 3
	#sleep 3
=begin	
	if(@browser1.link(:id,"sb-nav-close").exists?)
	      @browser1.link(:id,"sb-nav-close").click
      end
=end      
      sleep 5
      
      if(@browser1.div(:id=>"loadingSurveys").exists?)
	      while @browser1.div(:id=>"loadingSurveys").visible? do
		      sleep 0.5
		      puts "waiting for surveys to load"
	      end
      end
      sleep 2
        body_text = @browser1.text
        body_text.should include("#{@dec_group_id}")
        @browser1.link(:id,"#{@dec_group_link}").click
        @browser1.button(:name,'Submit').click
        sleep(2)
        @browser1.window(:title => /Google/).use do
            @browser1.goto("http://sm1mr.com/ssred.php?S=3&ID=")
            body_text = @browser1.text
            body_text.should include("SORRY")
        end
        @browser1.link(:text,"Logout").click
        system("cookies.bat")
        @browser1.close
    end
  
    it "To check if the stats are correctly shown" do
        sleep 5
        @browser.refresh
        #puts @browser.text
        @browser.text.should include("uSamp")
        @browser.text.should include("5 3 1 1 1 33.3%")
        @browser.text.should include("Total   10 3 1 1 1 Avg. 16.7%")
    end
    
    it "To successfully close a project" do
        @browser.link(:text,"Close").click
        sleep 3
        @browser.driver.switch_to.alert.accept
    end
    

    it "To check the feasibility report and the count" do
        @browser.goto("https://network.usamp.com/SelfServe/index.php?mode=report/feasibilityRep")
        @browser.checkbox(:id,"PL[0]").set
        
        @browser.link(:text,/Demographic Targeting/).click
        while @browser.div(:id=>"fancybox-loading").visible? do
		sleep 0.5
		puts "waiting for element"
	end
	sleep 4
        @browser.link(:text,/Age /).click
        while @browser.div(:id=>"fancybox-loading").visible? do
		sleep 0.5
		puts "waiting for element"
	end
	sleep 4
        @browser.text_field(:id,"txtAgeGenderRangeLower_1").set("90")
        @browser.text_field(:id,"txtAgeGenderRangeUpper_1").set("99")
        sleep 2
        @browser.checkbox(:id,"rdFemaleAgeGender1").set
        #@browser.link(:text,/SAVE and add another category/).click
        @browser.link(:text,/Done/).click
	sleep 3
        @browser.link(:text,/90-99/).should exist
        
        @browser.link(:text,/Geographic Targeting/).click
	while @browser.div(:id=>"fancybox-loading").visible? do
		sleep 0.5
		puts "waiting for element"
	end
	sleep 4
        @browser.link(:text,/Zip Code/).click
        while @browser.div(:id=>"fancybox-loading").visible? do
		sleep 0.5
		puts "waiting for element"
        end
	sleep 4
        @browser.text_field(:id,"txtZipList").set("98765")
        @browser.link(:text,/Done/).click
	sleep 4
        @browser.link(:text,/98765/).should exist
        
        @browser.link(:text,"Get Sample Counts").click
        while @browser.div(:id=>"spanDisplayRefrStatsLoadingStatus").visible? do
            sleep 1
        end
            
        body_text = @browser.html
        html_array = body_text.split(/\n/)
        0.upto(html_array.size - 1) { |index|
        if(html_array[index] =~ />Surveyhead </)
            @code = html_array[index+2]
            #puts html_array[index]
            #puts html_array[index+1]
            #puts html_array[index+2]
            
            puts @code
            break
            else
                next
            end
            }
            @code1 = @code.slice(40..41)
            #puts @code1
            @code1 = @code1.gsub(/,/, "")
            @number = @code1.to_i

            @number.should > 5
            @number.should < 30
    end
    
    
    after(:all) do
        @browser.link(:text,"Log Out").click
        @browser.close
        puts "Test case for production has completed"
    end
end

