#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"
$site_id = "2"


#MEMBER LOGIN DETAILS

$m_email = "rahul_halankar@persistent.co.in"
$m_passwd = "test"

