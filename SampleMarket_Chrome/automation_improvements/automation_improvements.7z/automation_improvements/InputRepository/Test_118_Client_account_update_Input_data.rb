#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

#NETWORK SITE CLIENT LOGIN DETAILS#

$usnet_email = "rahul_halankar@persistent.co.in"
$usnet_passwd = "1234"
$type = "Client"

$wd=Dir.pwd




