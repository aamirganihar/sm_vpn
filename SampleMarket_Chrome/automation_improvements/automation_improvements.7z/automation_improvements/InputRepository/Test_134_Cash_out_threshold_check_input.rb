$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"

$username1 = "test21_des1606@mailop.com"
$username2 = "nitin_kumar@persistent.co.in"
