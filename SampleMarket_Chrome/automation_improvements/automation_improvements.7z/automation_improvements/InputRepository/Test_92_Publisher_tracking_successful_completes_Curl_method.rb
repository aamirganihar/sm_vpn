$project_name = "PR10840"
$qg_id = "30529"
$username = "test22_des2740@mailop.com"
$username1 = "test22_des0807@mailop.com"
$QG_STATUS = "Setting Up"
$QG_CLOSE_DATE = "2010-12-30"
$N_Sample_Size = "100"
$INCIDENCE = "2"
$INCIDENCE_RANGE = "General_population"
$QG_CATEGORY = "Business"
$LENGTH	 = "Time"
$TIME_QNS = "2"
$CPI	 = "10"
$REW_TYPE = "Cash"
$REW_AMOUNT = "10"
$NEW_REW_AMOUNT = "20"
$FAIL_REW_AMT = "1"
$OVERQUOTA_REW_AMT = "1"
$SURVEY_URL = "http://203.199.26.75/usamp/TEST_SURVEY.php"
$PUBLISHER_NAME = "Test PUB (30 Sept)"

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"

$Country = "United States"
$Language1 = "German"
$Lower_Age = "10"
$Upper_age = "99"
$Gender = "Male"
$Origin = "Germany"
$Education = "High school graduate"
$Employment = "Full-Time Employee"
$Industry = "Agribusiness"
$Maritial_status = "Separated"
$Language = "Arabic"
$username = "test_desautomation@mailop.com"
$member_id = "4583453"
$template_name = "text only template"

#MEMBER CREATION DETAILS#
$FNAME = "Nitin"
$LNAME = "Kumar"
$COUNTRY = "United States"
$LANGUAGE = "Deutsch"
$STATE	 = "California"
$ZIP = "90001"
$DATE	 = "02"
$MONTH	 = "Januar"
$YEAR	 = "1957"
$EMAILID = "test21_des@mailop.com"
$MAIL = "test21.des"
$PASSWORD = "test"
$INCOME	 = "10,000- 19,999"
$EDUCATION = "Kein Sekundarschulabschluss"
$EMPLOYMENT = /Teilzeitbesc/  #"h�ftigt"
$INDUSTRY = "Computer: Software/Dienstleistungen"
$ROLE	 = "Finanzen"
$JOB_TITLE = "Analyst/in"
$MARITIAL_STATUS = "Nie verheiratet"
$Ethnicity = "Gemischt rassischer Abstammung von den Karibikinseln"
$cOUNTRY_ORIGIN = "United States"

#The language speaking value depends from person to person. There are certain values that can be set#
#I am using the values for English --> 2, French --> 3, #
#Here it is default set to English as reading and writing and using the default values#
$CHILDREN = "N"
#User invite #
#I would like to receive a maximum of 1 email each week. --> 1#
#I would like to receive a maximum of 2-3 emails each week.--> 3#
#I would like to receive a maximum of 4-5 emails each week.--> 5#
#I would like to receive a maximum of 6-7 emails each week.--> 7#
#I do not have a preference in the maximum number of emails I receive each week.--> 0#
$INVITE	 = "0"
