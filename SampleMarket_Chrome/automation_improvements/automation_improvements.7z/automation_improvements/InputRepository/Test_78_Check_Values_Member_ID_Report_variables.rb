$Usamp_Login_Username='vipul_paikane@persistent.co.in'
$Usamp_Login_Password='test'
$Network_Login_Username='miriam.talamini@idgtechnet.comxyz'
$Network_Login_Password='IDG123'
