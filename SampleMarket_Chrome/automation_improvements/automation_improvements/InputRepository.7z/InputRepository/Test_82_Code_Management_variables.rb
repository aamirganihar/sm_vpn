$Usamp_Login_Username='vipul_paikane@persistent.co.in'
$Usamp_Login_Password='test'
$mail_initial='Mail_Reward'
$Reward='Automation'

$Description="
<p> Reward Desciption </p>
<p>  Data
Reward Name : %%rewardname%% 	
First name : %%firstname%% 	
Email : %%email%% 
</p>"

$Catalog="
<p> Reward Desciption </p>
<p>  Data 
Reward Name : %%rewardname%% 	
First name : %%firstname%% 	
Email : %%email%% 
</p>"

$Redemption="
<p> Reward Desciption </p>
<p>  Gift code : %%giftcode%% 	Gift Amount : %%giftamount%% 	Gift Url : %%gifturl%% </p>"

$Email="
<p> Email Contents</p><p>  DataInstructions : %%instructions%% 	Password : %%password%% </p>"
