$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"