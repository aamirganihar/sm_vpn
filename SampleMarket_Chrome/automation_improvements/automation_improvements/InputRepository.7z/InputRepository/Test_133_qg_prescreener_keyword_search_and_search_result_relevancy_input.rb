$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"
$qg_id = "47674"