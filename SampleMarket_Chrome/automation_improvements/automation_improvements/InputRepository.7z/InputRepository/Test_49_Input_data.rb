#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"

$wd=Dir.pwd
$qgidpth = $wd+"/Input Repository/QG_ID.txt"

# SURVEYHEAD LOGIN CREDENTIALS

$m1_mid = "M1798731"
$m1_email = "rfda@dh.comxyz"
$m1_passwd = "rfda@dh.com"
$m1_site = "Surveyhead"

#PUBLISHER DETAILS

$pub_id = "PU164"

# CATEGORIES

$match_cat = "Business"
$mismatch_cat = "Computers"
