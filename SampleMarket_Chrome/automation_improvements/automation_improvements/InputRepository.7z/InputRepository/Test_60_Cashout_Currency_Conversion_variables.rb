$Usamp_Login_Username='vipul_paikane@persistent.co.in'
$Usamp_Login_Password='test'
$Surveyhead_Login_Username='Test_CanadianUser.des@mailop.com'
$Surveyhead_Login_Password='test'
$Us_Dollar_To_Canadian_Dollars=1.0128
$Paypal_Email_id='Test_CanadianUser.des@mailop.com'