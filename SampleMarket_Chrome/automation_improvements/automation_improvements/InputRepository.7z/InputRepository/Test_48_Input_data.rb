#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"

#NETWORK SITE CLIENT LOGIN DETAILS#

$net_email = "rahul_halankar@persistent.co.in"
$net_passwd = "1234"
$type = "Client"

#SUPPLIER ADDITION DETAILS#

$sup_link_index = "45"
$sup_name = "Greenfield Online"