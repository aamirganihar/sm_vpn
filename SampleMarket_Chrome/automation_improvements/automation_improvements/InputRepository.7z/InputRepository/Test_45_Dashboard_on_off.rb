#DESCRIPTION: This file contains data that is required by the "" script , to verify whether #

#NOTE: All the lines enclosed within two '#' characters are comments.#
#      The lines with actual data are without '#' characters and,#
#      In the data, text before the '::' character (text to the left of the '::' character) are FIELD NAME#
#      And text after the '::' character (text to the right of '::' character) are ACTUAL DATA#
#      The '::' character is a separator between the Field name and the actual data and hence is very important#
#      Make sure the '::' chracter is not modified#
#      Do not alter the sequence in which the test data is written #

#UNITED SAMPLE LOGIN DETAILS#
$email = "rahul_halankar@persistent.co.in"
$password = "rahul123"
$member_id = "M2888253"

