module BasicData
  USAMP_NETWORK_LOGIN = "nitin_kumar@mailinator.com"
  USAMP_NETWORK_PASSWORD = "test"
  USAMP_NAME = "Nitin Kumar"
  USAMP_ADMIN_LOGIN = "nitin_kumar@persistent.co.in"
  USAMP_ADMIN_PASSWORD = "test"
  SURVEY_URL = "http://www.instant.ly/s/gxZWu/?id=%%Token%%"
end
