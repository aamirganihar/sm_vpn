#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"


# SURVEYHEAD/PL SIGNUP DETAILS

$url = "http://www.sm.p.surveyhead.com"
$country = "Djibouti"
$city = "Dikhil"
$lang = "English"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"
$inc_level = "Decline to answer"
$origin = "Mayotte"
$education = "Advanced degree"
$state = "Dikhil"



