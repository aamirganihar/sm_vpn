module BasicData
  USAMP_NETWORK_LOGIN = "nitin_kumar@persistent.co.in"
  USAMP_NETWORK_PASSWORD = "test"
  USAMP_NAME = "Nitin Kumar"
end
