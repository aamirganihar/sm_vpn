$Usamp_Login_Username='vipul_paikane@persistent.co.in'
$Usamp_Login_Password='test'
$Publisher_group_initial='Target - DMA' 
pub_name= Time.now
      pub_name = pub_name.to_s
      pub_name = pub_name.slice(0..18)
      pub_name = "Auto_Group"+pub_name
      
$Publisher_Group_Name=pub_name
$Publisher_Country='United States'
$Publisher_Name='IDG_Cell Phone Signal'