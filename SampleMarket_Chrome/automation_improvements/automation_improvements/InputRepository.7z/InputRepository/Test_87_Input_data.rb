#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"
$site_id = "2"

$wd=Dir.pwd
$qgidpth = $wd+"/Input Repository/QG_ID.txt"
$pridpth = $wd+"/Input Repository/Project_Id_In_Use.txt"

# QG CRITERIA DETAILS

$inc_level = "Decline to answer"
$origin = "Mayotte"
$education = "Advanced degree"
$state = "Newfoundland and Labrador"

# SURVEYHEAD/PL SIGNUP DETAILS

$url = "http://www.sm.p.surveyhead.com"
$country = "Canada"
$lang = "English"
$pcode_match = "A0A 1A0"
$day = "04"
$month = "July"
$year = "1980"
$employment = "Homemaker"
$marrital_status = "Never married"


