$Usamp_Login_Username='rahul_halankar@persistent.co.in'
$Usamp_Login_Password='rahul123'
$Publisher_fname='rommel_pub'
$txtPubFname1='rommel_pub2'
$txtPubLname1='rommel_pub2'
$txtPubTitle1='rommel_pub2'
$txtPubEmail1='rommel_pub2@mailop.com'
$txtPubPassword1='test'

