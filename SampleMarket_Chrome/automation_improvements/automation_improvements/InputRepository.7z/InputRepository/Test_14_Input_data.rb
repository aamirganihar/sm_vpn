#DESCRIPTION: This file contains details needed to login to Surveyhead site and Usampadmin site which is required by the 
#the script "" 

# USAMP ADMIN LOGIN CREDENTIALS

$usamp_email = "rahul_halankar@persistent.co.in"
$usamp_passwd = "rahul123"

$wd=Dir.pwd
$qgidpth = $wd+"/Input Repository/QG_ID.txt"

# SURVEYHEAD LOGIN CREDENTIALS

$m1_mid = "M4584659"
$m1_email = "test_aut123qa@hjsk.com"
$m1_passwd = "test_aut123qa@hjsk.com"
$m1_site = "Surveyhead"

$m2_mid = "M4584666"
$m2_email = "test_aut125qa@hjsk.com"
$m2_passwd = "test_aut125qa@hjsk.com"
$m2_site = "Surveyhead"