$Usamp_Login_Username='vipul_paikane@persistent.co.in'
$Usamp_Login_Password='test'
$Publisher_group='Target - Zip Code' 

